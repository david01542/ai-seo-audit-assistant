# AI SEO Audit Assistant

A small, practical AI-assisted SEO audit application built with Python and Streamlit.

## What it does

Enter a public website URL and the tool:

1. Fetches the page.
2. Extracts SEO signals such as:
   - Title and title length
   - Meta description and length
   - H1/H2 headings
   - Canonical URL
   - Robots meta tag
   - Image alt-text coverage
   - Link count
   - Approximate word count
3. Sends the crawl snapshot to an OpenAI model.
4. Generates a client-ready SEO audit covering:
   - Executive summary
   - Critical issues
   - On-page SEO
   - Technical SEO
   - Content opportunities
   - Title/meta recommendations
   - Prioritized action plan
5. Lets you download the audit as Markdown.

## Why this is a real AI project

The crawler gathers structured website data, then an OpenAI model interprets those signals and turns them into prioritized recommendations. The AI layer is separated from the crawling layer so the workflow can be extended later with Search Console, PageSpeed, keyword data, or competitor analysis.

## Run locally

```bash
git clone https://github.com/YOUR-USERNAME/ai-seo-audit-assistant.git
cd ai-seo-audit-assistant

python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Run:

```bash
streamlit run app.py
```

Open the local URL shown by Streamlit.

## API key

Create an OpenAI API key and either:

- paste it into the sidebar when using the app, or
- create a `.env`/deployment secret named `OPENAI_API_KEY`.

Never commit a real API key to GitHub.

## Deploy

A simple public option is Streamlit Community Cloud:

1. Push this repository to GitHub.
2. Create a Streamlit Community Cloud app.
3. Select this repository and `app.py`.
4. Add `OPENAI_API_KEY` under the app's secrets.
5. Deploy.

Then your repository and live application can be used as portfolio evidence.

## Example portfolio description

> Built an AI-assisted SEO audit application that crawls a webpage, extracts technical and on-page SEO signals, and uses an OpenAI model to generate prioritized, client-ready recommendations. Built with Python, Streamlit, BeautifulSoup, Requests, and OpenAI's API.

## Important

Only audit websites you are authorized to access. Respect robots.txt, rate limits, terms of service, and applicable laws. This is an audit assistant, not a substitute for manual SEO verification.
